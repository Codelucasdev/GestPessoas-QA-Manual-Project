"""Prepare privacy copies; preserve all pixels outside the two masks.

Usage: python tools/prepare_evidence.py SOURCE_DIRECTORY OUTPUT_DIRECTORY
Original captures are retained separately, not committed.
"""
from pathlib import Path
import hashlib
import json
import math
import sys
from PIL import Image, ImageDraw, ImageChops

source, output = map(Path, sys.argv[1:3])
manifest = []
for path in sorted(source.rglob('*')):
    if not path.is_file():
        continue
    original = Image.open(path).convert('RGB')
    width, height = original.size
    top, bottom = math.ceil(height * .043), math.floor(height * .958)
    edited = original.copy()
    draw = ImageDraw.Draw(edited)
    draw.rectangle((0, 0, width-1, top-1), fill='#20252b')
    draw.rectangle((0, bottom, width-1, height-1), fill='#20252b')
    assert ImageChops.difference(original.crop((0, top, width, bottom)), edited.crop((0, top, width, bottom))).getbbox() is None
    relative = path.relative_to(source).with_suffix('.png')
    target = output / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    edited.save(target, format='PNG', optimize=True)
    manifest.append({'path':str(relative), 'size':[width,height], 'masked_rows':[[0,top-1],[bottom,height-1]], 'sha256':hashlib.sha256(target.read_bytes()).hexdigest(), 'unmasked_pixels_unchanged':True})
(output.parent/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(f'{len(manifest)} captures prepared and checked')
